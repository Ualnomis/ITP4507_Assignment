package Factory;

import Menu.Menu;

public abstract class MenuFactory {
    public abstract Menu createMenu();
}
