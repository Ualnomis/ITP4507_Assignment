package LunchSet;

public class MainDish extends Dish {
    
}
