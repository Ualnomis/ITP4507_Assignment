package LunchSet.Side;
public class FrenchFries implements Side {
    public String toString() {
        return "French fries";
    }
}
