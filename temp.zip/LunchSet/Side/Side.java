package LunchSet.Side;
public interface Side {
    public String toString();
}
