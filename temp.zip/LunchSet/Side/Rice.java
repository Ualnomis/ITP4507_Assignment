package LunchSet.Side;
public class Rice implements Side{
    public String toString() {
        return "rice";
    }
}
