package LunchSet.Side;
public class Spaghetti implements Side {
    public String toString() {
        return "spaghetti";
    }
}
