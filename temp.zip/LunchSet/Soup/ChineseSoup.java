package LunchSet.Soup;

public class ChineseSoup implements Soup {
    public String toString() {
        return "Chinese Soup";
    }
}
