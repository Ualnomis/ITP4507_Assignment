package LunchSet.Soup;

public class WesternSoup implements Soup {
    public String toString() {
        return "Western Soup";
    }
}
