package LunchSet.Soup;

public interface Soup {
    String toString();
}